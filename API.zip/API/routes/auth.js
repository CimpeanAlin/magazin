const express = require('express');
const CryptoJS = require('crypto-js');
const jwt = require('jsonwebtoken');
const User = require('../models/User'); // Adjust the path as necessary

const router = express.Router();

// Register
router.post("/register", async (req, res) => {
  const newUser = new User({
    username: req.body.username, // Consistent field name
    email: req.body.email,
    password: CryptoJS.AES.encrypt(
      req.body.password,
      "crypt"
    ).toString(),
  });

  try {
    const savedUser = await newUser.save();
    res.status(201).json(savedUser);
  } catch (err) {
    res.status(500).json(err);
  }
});

// Login
router.post("/login", async (req, res) => {
  try {
    const user = await User.findOne({
      username: req.body.username, // Consistent field name
    });

    if (!user) {
      console.log("No user found, sending 401 response");
      return res.status(401).json("Wrong User Name");
    }

    const hashedPassword = CryptoJS.AES.decrypt(user.password, "crypt");
    const originalPassword = hashedPassword.toString(CryptoJS.enc.Utf8);
    const inputPassword = req.body.password;

    console.log("Original Password:", originalPassword);  // Log decrypted password
    console.log("Input Password:", inputPassword);  // Log input password

    if (originalPassword !== inputPassword) {
      console.log("Password mismatch, sending 401 response");
      return res.status(401).json("Wrong Password");
    }

    const accessToken = jwt.sign(
      {
        id: user._id,
        isAdmin: user.isAdmin,
      },
      "crypt",
      { expiresIn: "3d" }
    );

    const { password, ...others } = user._doc;
    console.log("Sending 200 response with user data and access token");
    return res.status(200).json({ ...others, accessToken });
  } catch (err) {
    console.log("Error caught, sending 500 response:", err);
    return res.status(500).json(err);
  }
});

module.exports = router;
